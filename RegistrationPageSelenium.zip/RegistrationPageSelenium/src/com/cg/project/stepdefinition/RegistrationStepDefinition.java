package com.cg.project.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


import com.cg.project.pagebeans.RegistrationPageBean;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition 
{
	private WebDriver driver;
	private RegistrationPageBean registerPage;
	
	@Before
	public void setUpStepEnv()
	{
		 System.setProperty("webdriver.chrome.driver", "D:\\3000117_Ankita_Dutta\\BDDCucumberSelenium\\chromedriver.exe");
	}
	
	
	@Given("^User is on the registration page$")
	public void user_is_on_the_registration_page() throws Throwable {
		 driver = new ChromeDriver();
		 driver.get("D:\\Users\\ADM-IG-HWDLAB1D\\Documents\\WebPages\\WebPages");
		 registerPage = PageFactory.initElements(driver,RegistrationPageBean.class);
	}

	@When("^User is trying to submit without entering 'UserId'$")
	public void user_is_trying_to_submit_without_entering_UserId() throws Throwable {
	   registerPage.clickSignUp();
	}

	@Then("^'User Id should not be empty / length be between (\\d+) to (\\d+)' alert message should be displayed$")
	public void user_Id_should_not_be_empty_length_be_between_to_alert_message_should_be_displayed(int arg1, int arg2) throws Throwable {
	  
	}

	@When("^User is trying to submit without entering 'Password'$")
	public void user_is_trying_to_submit_without_entering_Password() throws Throwable {
	   
	}

	@Then("^'Password should not be empty / length be between (\\d+) to (\\d+)' alert message should be displayed$")
	public void password_should_not_be_empty_length_be_between_to_alert_message_should_be_displayed(int arg1, int arg2) throws Throwable {
	   
	}

	@When("^User is trying to submit request without entering 'name'$")
	public void user_is_trying_to_submit_request_without_entering_name() throws Throwable {
	    
	}

	@Then("^'Name should not be empty and must have alphabet characters only' alert message should be displayed$")
	public void name_should_not_be_empty_and_must_have_alphabet_characters_only_alert_message_should_be_displayed() throws Throwable {
	  
	}
	@When("^User is trying to submit request without entering 'address'$")
	public void user_is_trying_to_submit_request_without_entering_address() throws Throwable {
	  
	}

	@Then("^'User address must have alphanumeric characters only' alert message should be displayed$")
	public void user_address_must_have_alphanumeric_characters_only_alert_message_should_be_displayed() throws Throwable {
	  
	}

	@When("^User is trying to submit request without selecting valid 'country'$")
	public void user_is_trying_to_submit_request_without_selecting_valid_country() throws Throwable {
	  
	}

	@Then("^'Select your country from the list' alert message should be displayed$")
	public void select_your_country_from_the_list_alert_message_should_be_displayed() throws Throwable {
	   
	}

	@When("^User is trying to submit request without entering 'zipCode'$")
	public void user_is_trying_to_submit_request_without_entering_zipCode() throws Throwable {
	   
	}

	@Then("^'ZIP code must have numeric characters only' alert message should be displayed$")
	public void zip_code_must_have_numeric_characters_only_alert_message_should_be_displayed() throws Throwable {
	   
	}

	@When("^User is trying to submit request without entering valid 'email'$")
	public void user_is_trying_to_submit_request_without_entering_valid_email() throws Throwable {
	   
	}

	@Then("^'You have entered an invalid email address!' alert message should be displayed$")
	public void you_have_entered_an_invalid_email_address_alert_message_should_be_displayed() throws Throwable {
	   
	}

	@When("^User is trying to submit request without selecting valid 'gender'$")
	public void user_is_trying_to_submit_request_without_selecting_valid_gender() throws Throwable {
	
	}

	@Then("^'Please Select gender' alert message should be displayed$")
	public void please_Select_gender_alert_message_should_be_displayed() throws Throwable {
	    
	}
	@When("^User is trying to submit after entering valid details$")
	public void user_is_trying_to_submit_after_entering_valid_details() throws Throwable {
	    
	}

	@Then("^'Your Registration with JobsWorld\\.com has successfully done plz check your registred email addres to activate your profile' alert message should be displayed$")
	public void your_Registration_with_JobsWorld_com_has_successfully_done_plz_check_your_registred_email_addres_to_activate_your_profile_alert_message_should_be_displayed() throws Throwable {
	    
	}
}
